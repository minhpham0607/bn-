package com.example.hrms.biz.commoncode.notification.service;

import com.example.hrms.biz.commoncode.notification.model.Notification;
import com.example.hrms.biz.commoncode.notification.model.dto.NotificationDTO;
import com.example.hrms.biz.commoncode.notification.repository.NotificationMapper;
import com.example.hrms.biz.commoncode.notification.model.WebSocketNotification;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class NotificationService {

    private final NotificationMapper notificationMapper;
    private final SimpMessagingTemplate messagingTemplate;
    
    public NotificationService(NotificationMapper notificationMapper, SimpMessagingTemplate messagingTemplate){
        this.notificationMapper = notificationMapper;
        this.messagingTemplate = messagingTemplate;
    }
    
    /**
     * Tạo thông báo mới
     */
    public Notification createNotification(Notification notification) {
        notificationMapper.insert(notification);
         // Đổi từ Entity sang DTO để thêm thông tin bổ sung
         NotificationDTO dto = notificationMapper.findById(notification.getId());
         addTimeAgo(dto);
         
         // Gửi thông báo qua WebSocket đến người nhận cụ thể
         messagingTemplate.convertAndSendToUser(
             notification.getReceiver(),
             "/queue/notifications",
             new WebSocketNotification("NEW_NOTIFICATION", dto)
         );
         
         return notification;
     }
    
    /**
     * Lấy danh sách thông báo của người dùng
     */
    public List<NotificationDTO> getNotificationsByReceiver(String receiver) {
        List<NotificationDTO> notifications = notificationMapper.findByReceiver(receiver);
        // Thêm thời gian tương đối
        notifications.forEach(this::addTimeAgo);
        return notifications;
    }
    
    /**
     * Lấy thông tin chi tiết của một thông báo
     */
    public NotificationDTO getNotificationById(Long id) {
        NotificationDTO notification = notificationMapper.findById(id);
        if (notification != null) {
            addTimeAgo(notification);
        }
        return notification;
    }
    
    /**
     * Đánh dấu thông báo đã đọc và gửi cập nhật WebSocket
     */
    public void markAsRead(Long id) {
        NotificationDTO notification = notificationMapper.findById(id);
        notificationMapper.markAsRead(id);
        
        // Gửi cập nhật trạng thái qua WebSocket
        messagingTemplate.convertAndSendToUser(
            notification.getReceiver(),
            "/queue/notifications",
            new WebSocketNotification("MARK_READ", id)
        );
    }
    
    /**
     * Đánh dấu tất cả thông báo đã đọc và gửi cập nhật WebSocket
     */
    public void markAllAsRead(String receiver) {
        notificationMapper.markAllAsRead(receiver);
        
        // Gửi cập nhật trạng thái qua WebSocket
        messagingTemplate.convertAndSendToUser(
            receiver,
            "/queue/notifications",
            new WebSocketNotification("MARK_ALL_READ", null)
        );
    }
    
    /**
     * Lấy số lượng thông báo chưa đọc
     */
    public int getUnreadCount(String receiver) {
        return notificationMapper.countUnread(receiver);
    }
    
    /**
     * Xóa thông báo và gửi cập nhật WebSocket
     */
    public void deleteNotification(Long id) {
        NotificationDTO notification = notificationMapper.findById(id);
        notificationMapper.delete(id);
        
        // Gửi cập nhật xóa thông báo qua WebSocket
        messagingTemplate.convertAndSendToUser(
            notification.getReceiver(),
            "/queue/notifications",
            new WebSocketNotification("DELETE_NOTIFICATION", id)
        );
    }
    
    /**
     * Lấy danh sách thông báo của một phòng ban
     */
    public List<NotificationDTO> getNotificationsByDepartment(Long departmentId) {
        List<NotificationDTO> notifications = notificationMapper.findByDepartment(departmentId);
        notifications.forEach(this::addTimeAgo);
        return notifications;
    }
    
    /**
     * Thêm thời gian tương đối vào DTO
     */
    private void addTimeAgo(NotificationDTO notification) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime createdAt = notification.getCreatedAt();
        long minutes = ChronoUnit.MINUTES.between(createdAt, now);
        
        if (minutes < 1) {
            notification.setTimeAgo("Vừa xong");
        } else if (minutes < 60) {
            notification.setTimeAgo(minutes + " phút trước");
        } else if (minutes < 24 * 60) {
            long hours = minutes / 60;
            notification.setTimeAgo(hours + " giờ trước");
        } else {
            long days = minutes / (24 * 60);
            notification.setTimeAgo(days + " ngày trước");
        }
    }
    
    /**
     * Tạo thông báo cho nhiều người nhận với WebSocket
     */
    public void createBulkNotifications(String title, String content, String sender, List<String> receivers) {
        for (String receiver : receivers) {
            Notification notification = new Notification();
            notification.setTitle(title);
            notification.setContent(content);
            notification.setSender(sender);
            notification.setReceiver(receiver);
            createNotification(notification);
        }
    }
    
    /**
     * Tạo thông báo cho toàn bộ phòng ban
     */
    public void createDepartmentNotification(String title, String content, String sender, Long departmentId, 
                                           List<String> usernames) {
        for (String username : usernames) {
            Notification notification = new Notification();
            notification.setTitle(title);
            notification.setContent(content);
            notification.setSender(sender);
            notification.setReceiver(username);
            createNotification(notification);
        }
    }
}