function openCreateForm() {
    // Reset các trường trong form
    $('#createTitle').val('');
    $('#createAttendees').val('');
    $('#createContent').val('');
    $('#createLinkMS').prop('checked', false);
    $('input[name="createRecurrence"]').prop('checked', false);
    $('#createDateOnly').val('');
    $('#createTimeOnly').val('');
    $('#createDateStartDaily').val('');
    $('#createDateEndDaily').val('');
    $('#createDateStartWeekly').val('');
    $('#createDateEndWeekly').val('');
    $('#createUsername').val('');
    $('input[type="checkbox"]').prop('checked', false);

    // Hiển thị modal form tạo booking
    $('#createBookingModal').modal('show');
    $('#createBookingModalLabel').text('Create Booking');
}

function toggleCreateRecurrence(type) {
    // Điều chỉnh hiển thị các phần của recurrence dựa trên lựa chọn
    document.getElementById('createRecurrenceOnly').style.display = type === 'only' ? 'block' : 'none';
    document.getElementById('createRecurrenceDaily').style.display = type === 'daily' ? 'block' : 'none';
    document.getElementById('createRecurrenceWeekly').style.display = type === 'weekly' ? 'block' : 'none';
}

function createBooking() {
    const selectedType = $('input[name="createRecurrence"]:checked').attr('id');

    let bookingData = {
        title: $('#createTitle').val(),
        attendees: $('#createAttendees').val(),
        content: $('#createContent').val(),
        linkMS: $('input[name="createLinkMS"]:checked').attr('id') === 'createLinkYes',
        bookingType: selectedType.replace('create', '').toUpperCase(),
        startTime: '',
        endTime: '',
        weekdays: null,
        username: $('#createUsername').val()
    };

    const now = new Date();

    if (selectedType === 'createOnly') {
        const date = $('#createDateOnly').val();
        const time = $('#createTimeOnly').val();       // Giờ bắt đầu// Giờ kết thúc (bạn cần thêm input này trong form HTML)

        if (!date || !time) {
            showNotification("Vui lòng nhập đầy đủ ngày, giờ bắt đầu và giờ kết thúc.");
            return;
        }

        const startDateTime = new Date(date);
        const [endHour, endMinute] = time.split(':'); // Renamed variables to avoid redeclaration
        const endDateTime = new Date(startDateTime);
        endDateTime.setHours(endHour);
        endDateTime.setMinutes(endMinute);

        if (isNaN(startDateTime.getTime()) || isNaN(endDateTime.getTime())) {
            showNotification("Ngày giờ không hợp lệ.");
            return;
        }

        const now = new Date();
        if (startDateTime < now) {
            showNotification("Thời gian bắt đầu không được ở quá khứ.");
            return;
        }

        const startHour = startDateTime.getHours(); // Renamed variables to avoid redeclaration
        const endHourCheck = endDateTime.getHours(); // Renamed variables to avoid redeclaration

        if (startHour < 8 || startHour >= 17 || endHourCheck < 8 || endHourCheck > 17) {
            showNotification("Thời gian đặt phòng phải nằm trong khoảng từ 8h sáng đến 17h chiều.");
            return;
        }

        if (endDateTime <= startDateTime) {
            showNotification("Giờ kết thúc phải sau giờ bắt đầu.");
            return;
        }

        bookingData.startTime = new Date(startDateTime.getTime() + 7 * 60 * 60 * 1000).toISOString().slice(0, 19).replace('T', ' ');
        bookingData.endTime = new Date(endDateTime.getTime() + 7 * 60 * 60 * 1000).toISOString().slice(0, 19).replace('T', ' ');
    } else if (selectedType === 'createDaily' || selectedType === 'createWeekly') {
        const start = selectedType === 'createDaily' ? $('#createDateStartDaily').val() : $('#createDateStartWeekly').val();
        const end = selectedType === 'createDaily' ? $('#createDateEndDaily').val() : $('#createDateEndWeekly').val();

        if (!start || !end) {
            showNotification("Please provide start and end dates.");
            return;
        }

        const startDate = new Date(start);
        const endDate = new Date(end);

        if (startDate < now || endDate < now) {
            showNotification("Start or end date cannot be in the past.");
            return;
        }

        if (endDate <= startDate) {
            showNotification("End date must be after start date.");
            return;
        }

        bookingData.startTime = new Date(startDate.getTime() + 7 * 60 * 60 * 1000).toISOString().slice(0, 19).replace('T', ' ');
        bookingData.endTime = new Date(endDate.getTime() + 7 * 60 * 60 * 1000).toISOString().slice(0, 19).replace('T', ' ');

        if (selectedType === 'createWeekly') {
            const weekdays = getSelectedWeekdays();
            if (!weekdays) return;
            bookingData.weekdays = weekdays;
        }
    }

    console.log("Creating booking with data:", bookingData);

    // Check for existing bookings
    jQuery.ajax({
        url: '/api/v1/bookings/check',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ startTime: bookingData.startTime, endTime: bookingData.endTime }),
        success: function(response) {
            if (response.data && response.data.length > 0) {
                let conflictMessage = "Time conflict with existing bookings:\n";
                response.data.forEach(booking => {
                    conflictMessage += `- ${booking.title} from ${booking.startTime} to ${booking.endTime}\n`;
                });
                showNotification(conflictMessage);
            } else {
                // Proceed with creating the booking
                jQuery.ajax({
                    url: '/api/v1/bookings',
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify(bookingData),
                    success: function(response) {
                        showNotification("Created booking successfully.", 'success');
                        $('#createBookingModal').modal('hide');
                        setTimeout(() => location.reload(), 4000);
                    },
                    error: function(xhr) {
                        if (xhr.status === 400 && xhr.responseJSON && xhr.responseJSON.retMsg) {
                            showNotification(`Failed to create booking: ${xhr.responseJSON.retMsg}`);
                        } else if (xhr.status === 409 && xhr.responseJSON && xhr.responseJSON.retMsg) {
                            showNotification(`Time conflict with existing booking: ${xhr.responseJSON.retMsg}`);
                        } else {
                            console.error('Error creating booking:', xhr.status, xhr.statusText, xhr.responseText);
                            showNotification("Failed to create booking.");
                        }
                    }
                });
            }
        },
        error: function(xhr) {
            console.error('Error checking booking conflict:', xhr.status, xhr.statusText, xhr.responseText);
            showNotification("Failed to check booking conflict.");
        }
    });
}

function getSelectedWeekdays() {
    const selectedDays = [];

    if ($('#createMo').prop('checked')) selectedDays.push('Mo');
    if ($('#createTu').prop('checked')) selectedDays.push('Tu');
    if ($('#createWe').prop('checked')) selectedDays.push('We');
    if ($('#createTh').prop('checked')) selectedDays.push('Th');
    if ($('#createFr').prop('checked')) selectedDays.push('Fr');

    if ($('#createSa').prop('checked') || $('#createSu').prop('checked')) {
        showNotification("Saturday and Sunday are not allowed for weekly bookings.");
        return null;
    }

    if (selectedDays.length === 0) {
        showNotification("Please select at least one weekday for weekly bookings.");
        return null;
    }

    return selectedDays.join(',');
}

hàm chỉnh thời gian UTC+7 and check time
