package com.example.hrms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmsApplicationTests {

    @Test
    void contextLoads() {
    }

}
