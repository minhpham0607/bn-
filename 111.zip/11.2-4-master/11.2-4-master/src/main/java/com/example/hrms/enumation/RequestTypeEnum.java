package com.example.hrms.enumation;

import lombok.Getter;

@Getter
public enum RequestTypeEnum {
    PAID_LEAVE("Nghỉ phép có lương"),
    UNPAID_LEAVE("Nghỉ phép không lương"),
    SICK_LEAVE("Nghỉ ốm"),
    MATERNITY_LEAVE("Nghỉ thai sản"),
    PATERNITY_LEAVE("Nghỉ chăm con"),
    COMPENSATORY_LEAVE("Nghỉ bù"),
    STUDY_LEAVE("Nghỉ học"),
    PERSONAL_LEAVE("Nghỉ việc riêng"),
    BEREAVEMENT_LEAVE("Nghỉ do tang lễ");

    private final String value;

    RequestTypeEnum(String value) {
        this.value = value;
    }
}
