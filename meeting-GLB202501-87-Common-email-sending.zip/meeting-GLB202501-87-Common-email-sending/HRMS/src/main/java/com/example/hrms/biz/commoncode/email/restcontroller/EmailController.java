package com.example.hrms.biz.commoncode.email.restcontroller;

import com.example.hrms.biz.commoncode.email.model.Email;
import com.example.hrms.biz.commoncode.email.service.EmailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/v1/email")
public class EmailController {

  private final EmailService emailService;

  @Autowired
  public EmailController(EmailService emailService) {
    this.emailService = emailService;
  }

  @PostMapping("/test")
  public ResponseEntity<Map<String, Object>> sendTestEmail(@RequestParam String to) {
    Map<String, Object> response = new HashMap<>();

    try {
      CompletableFuture<Boolean> future = emailService.sendEmail(
          to,
          "Test Email from HRMS",
          "This is a test email from the HRMS system."
      );

      // Để đơn giản, chúng ta đợi kết quả trả về
      boolean result = future.get();

      response.put("success", result);
      response.put("message", result ?
          "Test email sent successfully" :
          "Failed to send test email");

      return ResponseEntity.ok(response);
    } catch (InterruptedException | ExecutionException e) {
      response.put("success", false);
      response.put("message", "Exception while sending email: " + e.getMessage());
      return ResponseEntity.ok(response);
    }
  }

  @PostMapping("/test-sync")
  public ResponseEntity<Map<String, Object>> sendTestEmailSync(@RequestParam String to) {
    boolean result = emailService.sendEmailSync(
        to,
        "Test Email from HRMS (Sync)",
        "This is a test email sent synchronously from the HRMS system."
    );

    Map<String, Object> response = new HashMap<>();
    response.put("success", result);
    response.put("message", result ?
        "Test email sent successfully" :
        "Failed to send test email");

    return ResponseEntity.ok(response);
  }

  @PostMapping("/send")
  public ResponseEntity<Map<String, Object>> sendCustomEmail(@RequestBody Email email) {
    Map<String, Object> response = new HashMap<>();

    try {
      CompletableFuture<Boolean> future = emailService.sendEmail(email);

      // Đợi kết quả
      boolean result = future.get();

      response.put("success", result);
      response.put("message", result ?
          "Custom email sent successfully" :
          "Failed to send custom email");

      return ResponseEntity.ok(response);
    } catch (InterruptedException | ExecutionException e) {
      response.put("success", false);
      response.put("message", "Exception while sending email: " + e.getMessage());
      return ResponseEntity.ok(response);
    }
  }

  @PostMapping("/send-sync")
  public ResponseEntity<Map<String, Object>> sendCustomEmailSync(@RequestBody Email email) {
    boolean result = emailService.sendEmailSync(email);

    Map<String, Object> response = new HashMap<>();
    response.put("success", result);
    response.put("message", result ?
        "Custom email sent successfully" :
        "Failed to send custom email");

    return ResponseEntity.ok(response);
  }
}