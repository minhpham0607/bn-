/**
 * WebSocket Notifications Handler
 * This file handles WebSocket connections for real-time notifications
 */

let stompClient = null;
let notificationCount = 0;

/**
 * Initialize WebSocket connection
 */
function connectWebSocket() {
  const username = localStorage.getItem('Username');
  if (!username) {
    console.warn('Cannot connect to WebSocket: No username found');
    return;
  }

  // Disconnect if already connected
  if (stompClient) {
    disconnectWebSocket();
  }

  const socket = new SockJS('/ws');
  stompClient = Stomp.over(socket);

  // Reduce console logging in production
  stompClient.debug = null;

  stompClient.connect({}, function(frame) {
    console.log('Connected to WebSocket: ' + frame);

    // Subscribe to personal notifications channel
    stompClient.subscribe('/user/' + username + '/queue/notifications', function(message) {
      handleNotification(JSON.parse(message.body));
    });

    // Subscribe to broadcast notifications (if needed)
    stompClient.subscribe('/topic/notifications', function(message) {
      handleNotification(JSON.parse(message.body));
    });

    // Load initial notification count
    loadNotificationCount();
  }, function(error) {
    console.error('WebSocket connection error:', error);
    // Try to reconnect after 5 seconds
    setTimeout(connectWebSocket, 5000);
  });
}

/**
 * Disconnect WebSocket
 */
function disconnectWebSocket() {
  if (stompClient !== null) {
    stompClient.disconnect();
    console.log('WebSocket disconnected');
  }
}

/**
 * Handle incoming notification
 */
function handleNotification(notification) {
  console.log('Received notification:', notification);

  // Handle different types of WebSocket messages
  switch(notification.action) {
    case 'NEW_NOTIFICATION':
      // New notification received
      showNotificationToast(notification.data);
      incrementNotificationCount();
      addNotificationToDropdown(notification.data);
      break;

    case 'MARK_READ':
      // A notification was marked as read
      updateNotificationAsRead(notification.data); // notification.data contains the ID
      break;

    case 'MARK_ALL_READ':
      // All notifications were marked as read
      markAllNotificationsAsRead();
      break;

    case 'DELETE_NOTIFICATION':
      // A notification was deleted
      removeNotificationFromUI(notification.data); // notification.data contains the ID
      break;

    default:
      console.warn('Unknown notification action:', notification.action);
  }
}

/**
 * Load notification count from the server
 */
function loadNotificationCount() {
  const username = localStorage.getItem('Username');
  if (!username) return;

  fetch('/api/v1/notifications/user/' + username + '/count')
  .then(response => response.json())
  .then(data => {
    if (data && data.data && typeof data.data.count !== 'undefined') {
      updateNotificationBadge(data.data.count);
    }
  })
  .catch(error => console.error('Error loading notification count:', error));
}

/**
 * Show notification toast
 */
function showNotificationToast(notification) {
  // Create toast element
  const toast = document.createElement('div');
  toast.className = 'notification-toast';
  toast.dataset.id = notification.id;

  // Set toast type color
  const typeClass = notification.type || 'info';
  toast.classList.add(typeClass);

  // Set content
  toast.innerHTML = `
        <div class="notification-header">
            <strong>${notification.title}</strong>
            <span class="notification-close">&times;</span>
        </div>
        <div class="notification-body">${notification.content}</div>
    `;

  // Add to document
  const toastContainer = document.getElementById('notification-toast-container');
  if (!toastContainer) {
    // Create container if it doesn't exist
    const container = document.createElement('div');
    container.id = 'notification-toast-container';
    document.body.appendChild(container);
    container.appendChild(toast);
  } else {
    toastContainer.appendChild(toast);
  }

  // Add close handler
  toast.querySelector('.notification-close').addEventListener('click', function() {
    toast.remove();
  });

  // Auto-remove after 5 seconds
  setTimeout(() => {
    if (toast.parentNode) {
      toast.classList.add('fadeOut');
      setTimeout(() => toast.remove(), 500);
    }
  }, 5000);
}

/**
 * Increment notification count and update badge
 */
function incrementNotificationCount() {
  notificationCount++;
  updateNotificationBadge(notificationCount);
}

/**
 * Update the notification badge in the UI
 */
function updateNotificationBadge(count) {
  notificationCount = count;

  // Update all notification badges
  const badges = document.querySelectorAll('.notification-badge');
  badges.forEach(badge => {
    if (count > 0) {
      badge.textContent = count > 99 ? '99+' : count;
      badge.style.display = 'block';
    } else {
      badge.style.display = 'none';
    }
  });
}

/**
 * Add notification to dropdown menu
 */
function addNotificationToDropdown(notification) {
  const dropdown = document.querySelector('.notification-dropdown-menu');
  if (!dropdown) return;

  // Create notification item
  const item = document.createElement('div');
  item.className = 'notification-item';
  item.dataset.id = notification.id;

  if (!notification.read) {
    item.classList.add('unread');
  }

  // Format time
  const timeAgo = notification.timeAgo || 'just now';

  // Set content
  item.innerHTML = `
        <div class="notification-title">${notification.title}</div>
        <div class="notification-content">${notification.content}</div>
        <div class="notification-footer">
            <span class="notification-time">${timeAgo}</span>
            <button class="notification-mark-read" title="Mark as read">
                <i class="fas fa-check"></i>
            </button>
        </div>
    `;

  // Add to dropdown
  const emptyMessage = dropdown.querySelector('.notification-empty');
  if (emptyMessage) {
    emptyMessage.remove();
  }

  // Insert at the beginning
  if (dropdown.firstChild) {
    dropdown.insertBefore(item, dropdown.firstChild);
  } else {
    dropdown.appendChild(item);
  }

  // Add click handler to mark as read
  item.querySelector('.notification-mark-read').addEventListener('click', function(e) {
    e.stopPropagation();
    markNotificationAsRead(notification.id);
  });

  // Add click handler to open notification details
  item.addEventListener('click', function() {
    openNotificationDetails(notification);
  });
}

/**
 * Mark notification as read
 */
function markNotificationAsRead(notificationId) {
  const username = localStorage.getItem('Username');
  if (!username) return;

  fetch(`/api/v1/notifications/${notificationId}/read`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    }
  })
  .then(response => {
    if (response.ok) {
      updateNotificationAsRead(notificationId);
    }
  })
  .catch(error => console.error('Error marking notification as read:', error));
}

/**
 * Update notification as read in UI
 */
function updateNotificationAsRead(notificationId) {
  // Update in dropdown
  const item = document.querySelector(`.notification-item[data-id="${notificationId}"]`);
  if (item) {
    item.classList.remove('unread');
  }

  // Decrement count if needed
  if (notificationCount > 0) {
    notificationCount--;
    updateNotificationBadge(notificationCount);
  }
}

/**
 * Mark all notifications as read
 */
function markAllNotificationsAsRead() {
  const username = localStorage.getItem('Username');
  if (!username) return;

  fetch(`/api/v1/notifications/user/${username}/read-all`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    }
  })
  .then(response => {
    if (response.ok) {
      // Update UI
      const items = document.querySelectorAll('.notification-item.unread');
      items.forEach(item => {
        item.classList.remove('unread');
      });

      // Reset count
      updateNotificationBadge(0);
    }
  })
  .catch(error => console.error('Error marking all notifications as read:', error));
}

/**
 * Remove notification from UI
 */
function removeNotificationFromUI(notificationId) {
  // Remove from dropdown
  const item = document.querySelector(`.notification-item[data-id="${notificationId}"]`);
  if (item) {
    if (item.classList.contains('unread') && notificationCount > 0) {
      notificationCount--;
      updateNotificationBadge(notificationCount);
    }
    item.remove();
  }

  // Show empty message if no notifications
  const dropdown = document.querySelector('.notification-dropdown-menu');
  if (dropdown && dropdown.children.length === 0) {
    const emptyMessage = document.createElement('div');
    emptyMessage.className = 'notification-empty';
    emptyMessage.textContent = 'No notifications';
    dropdown.appendChild(emptyMessage);
  }
}

/**
 * Open notification details
 */
function openNotificationDetails(notification) {
  // Mark as read if unread
  if (!notification.read) {
    markNotificationAsRead(notification.id);
  }

  // Handle different notification types
  switch(notification.type) {
    case 'request':
      window.location.href = '/requests';
      break;

    case 'meeting':
      window.location.href = '/meeting-room';
      break;

    default:
      // Show details in a modal or take appropriate action
      console.log('Opening notification:', notification);
  }
}

/**
 * Initialize notifications when page loads
 */
document.addEventListener('DOMContentLoaded', function() {
  // Connect to WebSocket
  if (typeof SockJS !== 'undefined' && typeof Stomp !== 'undefined') {
    connectWebSocket();
  } else {
    console.error('WebSocket libraries not loaded');
  }

  // Handle logout
  window.addEventListener('beforeunload', disconnectWebSocket);

  // Set up mark all as read button
  const markAllReadBtn = document.querySelector('.mark-all-read');
  if (markAllReadBtn) {
    markAllReadBtn.addEventListener('click', markAllNotificationsAsRead);
  }
});