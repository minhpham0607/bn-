package com.example.hrms.biz.commoncode.notification.controller.rest;

import com.example.hrms.biz.commoncode.notification.model.Notification;
import com.example.hrms.biz.commoncode.notification.model.dto.NotificationDTO;
import com.example.hrms.biz.commoncode.notification.service.NotificationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/notifications")
public class NotificationRestController {

    private final NotificationService notificationService;
    
    public NotificationRestController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }
    
    /**
     * Tạo mới thông báo
     */
    @PostMapping
    public ResponseEntity<Notification> createNotification(@RequestBody Notification notification) {
        Notification created = notificationService.createNotification(notification);
        return ResponseEntity.ok(created);
    }
    
    /**
     * Tạo thông báo cho nhiều người nhận
     */
    @PostMapping("/bulk")
    public ResponseEntity<Map<String, String>> createBulkNotifications(
            @RequestBody Map<String, Object> request) {
        String title = (String) request.get("title");
        String content = (String) request.get("content");
        String sender = (String) request.get("sender");
        @SuppressWarnings("unchecked")
        List<String> receivers = (List<String>) request.get("receivers");
        
        notificationService.createBulkNotifications(title, content, sender, receivers);
        return ResponseEntity.ok(Map.of("message", "Đã gửi thông báo cho " + receivers.size() + " người nhận"));
    }
    
    /**
     * Lấy danh sách thông báo của người dùng
     */
    @GetMapping("/user/{username}")
    public ResponseEntity<List<NotificationDTO>> getNotifications(@PathVariable String username) {
        List<NotificationDTO> notifications = notificationService.getNotificationsByReceiver(username);
        return ResponseEntity.ok(notifications);
    }
    
    /**
     * Lấy chi tiết thông báo
     */
    @GetMapping("/{id}")
    public ResponseEntity<NotificationDTO> getNotificationById(@PathVariable Long id) {
        NotificationDTO notification = notificationService.getNotificationById(id);
        return ResponseEntity.ok(notification);
    }
    
    /**
     * Đánh dấu thông báo đã đọc
     */
    @PutMapping("/{id}/read")
    public ResponseEntity<Void> markAsRead(@PathVariable Long id) {
        notificationService.markAsRead(id);
        return ResponseEntity.ok().build();
    }
    
    /**
     * Đánh dấu tất cả thông báo đã đọc
     */
    @PutMapping("/user/{username}/read-all")
    public ResponseEntity<Void> markAllAsRead(@PathVariable String username) {
        notificationService.markAllAsRead(username);
        return ResponseEntity.ok().build();
    }
    
    /**
     * Lấy số lượng thông báo chưa đọc
     */
    @GetMapping("/user/{username}/count")
    public ResponseEntity<Map<String, Integer>> getUnreadCount(@PathVariable String username) {
        int count = notificationService.getUnreadCount(username);
        return ResponseEntity.ok(Map.of("count", count));
    }
    
    /**
     * Xóa thông báo
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNotification(@PathVariable Long id) {
        notificationService.deleteNotification(id);
        return ResponseEntity.ok().build();
    }
    
    /**
     * Lấy danh sách thông báo của phòng ban
     */
    @GetMapping("/department/{departmentId}")
    public ResponseEntity<List<NotificationDTO>> getNotificationsByDepartment(@PathVariable Long departmentId) {
        List<NotificationDTO> notifications = notificationService.getNotificationsByDepartment(departmentId);
        return ResponseEntity.ok(notifications);
    }
}